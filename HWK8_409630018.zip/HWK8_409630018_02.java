
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class HWK8_409630018_02 {

    static ArrayList<Integer> existlist = new ArrayList<Integer>();
    static Random r = new Random();
    static int cnt = 0;
    static int times = 0;

    public static class TestGridLayout extends JFrame implements ActionListener {

        JButton[] BTNs = new JButton[9];

        TestGridLayout() {
            Container cp = this.getContentPane();
            this.setLayout(new GridLayout(3, 3));
            while (cnt != 9) {
                int num = 1 + r.nextInt(9 - 1 + 1);
                if (!existlist.contains(num)) {
                    existlist.add(num);
                    BTNs[cnt] = new JButton("" + num);
                    cp.add(BTNs[cnt]);
                    BTNs[cnt].addActionListener(this);
                    cnt++;
                }
            }
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            setSize(300, 300);
            setVisible(true);
        }

        public void actionPerformed(ActionEvent e) {
            for (int i = 0; i < BTNs.length; i++) {
                if (e.getSource() == BTNs[i] && e.getSource() != BTNs[4]) {
                    String te = BTNs[i].getText();
                    BTNs[i].setText(BTNs[4].getText());
                    BTNs[4].setText(te);
                    this.validate();
                    System.out.println("move times : " + (++times));
                }
            }

        }
    }

    public static void main(String args[]) {
        new TestGridLayout();
    }
}
