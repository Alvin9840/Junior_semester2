
import java.util.Arrays;
import java.util.Random;

class OpThread extends Thread {

    int[] a, b, c;
    int mode; // 0:+, 1:-, 2:*, 3:/, 4:%

    OpThread() {
        super();
    }

    OpThread(int[] _a, int[] _b, int[] _c, int mode) {
        a = _a;
        b = _b;
        c = _c;
        this.mode = mode;
    }

    public void run() {
        if (a.length != b.length || b.length != c.length) {
            return;
        }
        for (int i = 0; i < c.length; i++) {
            c[i] = calc(a[i], b[i]);
        }
    }

    final private int calc(int x, int y) {
        return switch (mode) {
            case 0 ->
                x + y;
            case 1 ->
                x - y;
            case 2 ->
                x * y;
            case 3 ->
                x / y;
            default ->
                0;
        };
    }
}

public class HWK4_409630018_02 {

    public static void main(String[] args) throws Exception {
        int size = 10 * 1024 * 1024;
        int[] a = new int[size];  // 10M data
        int[] b = new int[size];
        int[] c = new int[size];
        int[] d = new int[size];
        double[] e = new double[size];
        int[] eTemp = new int[size];

        Random r = new Random(111);
        for (int i = 0; i < a.length; i++) {
            a[i] = 50 + r.nextInt(200 - 50 + 1);
            b[i] = 50 + r.nextInt(200 - 50 + 1);
        }

        // 使用多緒執行完成以下所需運算，儘量加速其運算速度，但結果需正確
        long start = System.currentTimeMillis();
        Thread t1 = new OpThread(a, b, c, 0); // c[i] = a[i]+b[i]
        Thread t2 = new OpThread(a, b, d, 1); // d[i] = a[i]-b[i]                
        Thread t3 = new OpThread(c, d, eTemp, 2);

        t1.start();
        t2.start();
        t1.join();
        t2.join();

        t3.start();
        t3.join();

        HWK4_409630018_02 h = new HWK4_409630018_02();
        double avg = h.avg(a, b);
        for (int i = 0; i < eTemp.length; i++) {
            e[i] = eTemp[i] / avg;
        }

        // 印出e[i]的前10個元素 (小數點3位)
        for (int i = 0; i < 10; i++) {
            System.out.printf("%.3f ", e[i]);
        }
        System.out.println("");

        // 印出e[i]的最後10個元素 (小數點3位)
        for (int i = e.length - 10; i < e.length; i++) {
            System.out.printf("%.3f ", e[i]);
        }
        System.out.println("");

        long totalTime = System.currentTimeMillis() - start;
        System.out.printf("CPU Time=%.3f sec(s)\n", totalTime / 1000.0);
    }

    public double avg(int[] a, int b[]) {
        double total = 0;
        for (int i = 0; i < a.length; i++) {
            total += a[i];
            total += b[i];
        }
        double avg = total / (a.length * 2);
        return avg;
    }
}
