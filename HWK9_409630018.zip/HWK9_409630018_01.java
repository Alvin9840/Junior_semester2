
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;

public class HWK9_409630018_01 extends javax.swing.JFrame {

    JFileChooser jfc = new JFileChooser();

    public HWK9_409630018_01() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Open = new javax.swing.JButton();
        Save = new javax.swing.JButton();
        SaveAs = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        FileText = new javax.swing.JTextArea();
        FileDir = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Open.setText("Open");
        Open.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OpenActionPerformed(evt);
            }
        });

        Save.setText("Save");
        Save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveActionPerformed(evt);
            }
        });

        SaveAs.setText("Save As...");
        SaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveAsActionPerformed(evt);
            }
        });

        FileText.setColumns(20);
        FileText.setRows(5);
        jScrollPane1.setViewportView(FileText);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 434, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Open)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Save)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SaveAs)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(FileDir)))
                .addContainerGap(76, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Open)
                    .addComponent(Save)
                    .addComponent(SaveAs)
                    .addComponent(FileDir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(110, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void OpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OpenActionPerformed
        // TODO add your handling code here:
        int result = jfc.showOpenDialog(null);

        if (result == jfc.APPROVE_OPTION) {
            File openFile = jfc.getSelectedFile();
            FileDir.setText(openFile.getAbsolutePath());

            try (BufferedReader br = new BufferedReader(new FileReader(openFile))) {
                String s;

                while ((s = br.readLine()) != null) {
                    FileText.append(s + "\n");

                }

            } catch (IOException ex) {
                System.out.println("ex = " + ex);
            }
        }
        System.out.println("Complete opening");
    }//GEN-LAST:event_OpenActionPerformed

    private void SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveActionPerformed
        // TODO add your handling code here:
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FileDir.getText().toString()))) {
            String[] lines = FileText.getText().split("\n");

            for (String i : lines) {
                bw.write(i);
                bw.newLine();
            }

        } catch (IOException ex) {
            System.out.println("ex = " + ex);
        }
        System.out.println("Complete saving!");
    }//GEN-LAST:event_SaveActionPerformed

    private void SaveAsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveAsActionPerformed
        // TODO add your handling code here:
        int result = jfc.showSaveDialog(null);

        if (result == jfc.APPROVE_OPTION) {
            File savingFile = jfc.getSelectedFile();

            try (BufferedWriter bw = new BufferedWriter(new FileWriter(savingFile))) {
                String[] lines = FileText.getText().split("\n");

                for (String i : lines) {
                    bw.write(i);
                    bw.newLine();
                }

            } catch (IOException ex) {
                System.out.println("ex = " + ex);
            }
        }
        System.out.println("Complete saving!");
    }//GEN-LAST:event_SaveAsActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HWK9_409630018_01().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField FileDir;
    private javax.swing.JTextArea FileText;
    private javax.swing.JButton Open;
    private javax.swing.JButton Save;
    private javax.swing.JButton SaveAs;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
