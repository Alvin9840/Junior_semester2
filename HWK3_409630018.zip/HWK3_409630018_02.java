
import java.util.ArrayList;
import java.util.Arrays;
import service_provider.*;

public class HWK3_409630018_02 {

    public static void main(String[] args) {
        int a[] = {1, 3, 5, 2};
        int b[] = {22, 33, 44, 55};
        int c[] = new int[a.length];

        //combine(a, b, c, lambda expression); a[i] + b[i] -> c[i]
        Tools.combine(a, b, c, (x, y) -> x + y);
        System.out.println("a[i] + b[i] -> " + Arrays.toString(c));

        //combine(a, b, c, lambda expression); a[i] * a[i] + sqrt( b[i] ) -> c[i]
        Tools.combine(a, b, c, (x, y) -> (int) ((x * x) + Math.sqrt(y)));
        System.out.println("a[i] * a[i] + sqrt( b[i] ) -> " + Arrays.toString(c));
    }
}
