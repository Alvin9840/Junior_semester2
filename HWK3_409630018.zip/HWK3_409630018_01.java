
import java.util.ArrayList;
import service_provider.*;

public class HWK3_409630018_01 {

    public static void main(String[] args) {
        int[] data = {55, 88, 44, 76, 87, 48};
        ArrayList<Integer> list = new ArrayList<>();
        for (int x : data) {
            list.add(x);
        }
        System.out.println("list: " + list);

        // -- 想直接使用service_provider套件中的updateList()函數更新同學分數
        //(a)平方
        Tools.updateList(list, x -> (int) Math.pow(x, 2));
        System.out.println("Method a: " + list);
        //(b)復原
        Tools.updateList(list, x -> (int) Math.sqrt(x));
        System.out.println("Method b: " + list);
        //(c)開根號*10
        Tools.updateList(list, x -> (int) (Math.sqrt(x) * 10));
        System.out.println("Method c: " + list);
    }
}
