package service_provider;

import java.util.ArrayList;

public class Tools {

    public static void updateList(ArrayList<Integer> list, Transform trans) {
        // [功能]: 更新list中所有元素，但更新方式可由使用決定        
        for (int i = 0; i < list.size(); i++) {
            list.set(i, trans.f(list.get(i))); // 更新串列元素
        }
    }

    public static void combine(int[] a, int[] b, int[] c, Transform2 trans) {
        for (int i = 0; i < c.length; i++) {
            c[i] = trans.f(a[i], b[i]);
        }
    }
}
