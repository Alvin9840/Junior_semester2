package service_provider;

public interface Transform2 {

    int f(int x, int y); // 自行定義如何對int x進行轉換，x進行轉換 x->????
}
