
import java.io.*;
import java.util.*;

/*
EX2: 撰寫一程式，啟動n條執行緒，能找出[1, m]中所有質數，最後將其存於一個檔案中(prime_m_n.txt)，並記錄執行時間(與單一執行緒比較)。
     例如，
	m=10_0000, n=4  	Thread 1 [1,25000]
				Thread 2 [25001,50000]
				Thread 3 [50001,75000]
				Thread 4 [75001,100000]
 */
public class HWK3_409630018_03 {

    public static class PrimeFinder implements Runnable {

        private int a;
        private int b;
        private int threadNo;

        public PrimeFinder(int a, int b, int threadNo) {
            this.a = a;
            this.b = b;
            this.threadNo = threadNo;
        }

        @Override
        public void run() {
            ArrayList<Integer> primeList = findPrimes(a, b);
            String fileName = "D:\\Data\\prime_" + a + "_" + b + ".txt";
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {

                bw.write(primeList + "");
            } catch (IOException e) {
                System.out.println("e = " + e);
            }
            System.out.println("Thread " + threadNo + " finished");
        }
    }

    public static void main(String[] args) throws IOException {
        int m = 10_0000;
        int threadNo = 4;
        int gap = m / threadNo; // 25000

        // DIY here
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("D:\\Data\\prime_m_n.txt"))) {
            long startTime = System.nanoTime();

            ArrayList<Thread> threads = new ArrayList<>();
            for (int i = 0; i < threadNo; i++) {
                int a = i * gap + 1;
                int b = (i + 1) * gap;
//                if (i == threadNo - 1) {
//                    b = m;
//                }
                threads.add(new Thread(new PrimeFinder(a, b, i)));
            }
            for (Thread i : threads) {
                i.start();
            }

            long endTime = System.nanoTime();
            System.out.println("Total time = " + (endTime - startTime) + " ms");

            long startTime1 = System.nanoTime();

            new Thread(new PrimeFinder(1, m, 100)).start();

            long endTime1 = System.nanoTime();
            System.out.println("Total time(Single) = " + (endTime1 - startTime1) + " ms");
        } catch (IOException ex) {
            System.out.println("ex = " + ex);
        }
    }

    public static ArrayList<Integer> findPrimes(int a, int b) {
        ArrayList<Integer> primeList = new ArrayList<>();
        // DIY
        for (int i = a; i < b; i++) {//從數字a到數字b，依序等於數字i
            if (isPrime(i)) {
                primeList.add(i);
            }
        }

        return primeList;
    }

    public static boolean isPrime(int number) {
        if (number <= 2) {
            return true;
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }
}
