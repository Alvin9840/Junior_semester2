
import java.io.*;
import java.net.*;
import java.util.*;

public class FileServer {

    static String pubDir = "D:/pub/";
    static boolean running = true;

    public static void main(String[] args) throws Exception {
        ServerSocket ss = new ServerSocket(5555);

        System.out.println("File Server Init ....\n");
        while (running) {
            Socket client = ss.accept();
            System.out.println("accept a client:" + client);

            // ==== ����client�ǨӪ��R�O
            DataInputStream dis = new DataInputStream(client.getInputStream());
            String cmd = dis.readUTF();
            DataOutputStream dos = new DataOutputStream(client.getOutputStream());

            // ==== �B�zclient���R�O
            if (cmd.equalsIgnoreCase("GetFile")) {
                String fileName = dis.readUTF();
                File[] fileList = new File(pubDir).listFiles();
                int i = 0;
                for (; i < fileList.length; i++) {
                    if (fileName.equals(fileList[i].getName())) {
                        dos.writeUTF("Success");
                        System.out.println("GetFile success");

                        int len = (int) fileList[i].length();
                        dos.writeInt(len);
                        byte[] b = new byte[len];
                        try (DataInputStream fdis = new DataInputStream(new FileInputStream(fileList[i]))) {
                            fdis.readFully(b);
                        }
                        dos.write(b);
                        dos.flush();
                        break;
                    } else {
                        dos.writeUTF("Fail");
                    }
                }
                if (i == fileList.length) {
                    dos.writeUTF("Fail");
                }

            } else if (cmd.equalsIgnoreCase("PutFile")) {
                String fileName = dis.readUTF();
                int len = dis.readInt();//�ɮת���
                byte[] b = new byte[len];
                dis.readFully(b);
                try (FileOutputStream fos = new FileOutputStream(pubDir + fileName)) {
                    fos.write(b);
                }
                dos.writeUTF("Success");
                System.out.println("PutFile success");
                dos.flush();

            } else if (cmd.equalsIgnoreCase("DelFile")) {
                String fileName = dis.readUTF();
                File[] fileList = new File(pubDir).listFiles();
                for (int i = 0; i < fileList.length; i++) {
                    if (fileName.equals(fileList[i].getName())) {
                        dos.writeUTF("Success");
                        System.out.println("DelFile success");
                        dos.flush();
                        fileList[i].delete();
                    } else {
                        dos.writeUTF("Fail");
                    }
                }

            }

            System.out.println("****************");
        }

        ss.close();
    }
}
//(a) �����ɮצ��A����"GetFile", "PutFile"���O�Aserver/client���ɮפ��O�m��c:/pub�Pc:/local��
//
//     (b) ����"DelFile"�R�O�A�i�R�����A����/pub/�ؿ������ɮ�  
//
//                       <client>                                                 <server>
//
//            (3)�R�O: DelFile, �Ѽ�: filename            (3-a) �^��: "Success", �L���[��� (�ɮצs�b�A�æ��\�R��)
//
//                                                                       (3-b) �^�� : "Fail", �L���[���   (�ɮפ��s�b�A�ΧR������)
