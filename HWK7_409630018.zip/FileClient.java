
import java.net.*;
import java.io.*;
import java.util.Scanner;

public class FileClient {

    static String pubDir = "D:/local/";

    public static void main(String[] args) throws Exception {
        Socket querySocket = new Socket("127.0.0.1", 5555);
        Scanner cin = new Scanner(System.in);

        // === (1) �ǰe�U���R�O��Server
        String fileName = "test1.txt";
        DataOutputStream dos = new DataOutputStream(querySocket.getOutputStream());
        System.out.println("GetFile, PutFile or DelFile: ");
        String a = cin.next();
        try {
            if (a.equals("GetFile")) {//�qServer�U���쥻�a
                dos.writeUTF("GetFile");
                dos.writeUTF(fileName);

            } else if (a.equals("PutFile")) {//�q���a�W�Ǩ�Server
                dos.writeUTF("PutFile");
                dos.writeUTF(fileName);
                File[] fileList = new File(pubDir).listFiles();

                for (int i = 0; i < fileList.length; i++) {
                    if (fileName.equals(fileList[i].getName())) {
                        int len = (int) fileList[i].length();
                        dos.writeInt(len);
                        byte[] b = new byte[len];
                        DataInputStream fdis = new DataInputStream(new FileInputStream(fileList[i]));
                        fdis.readFully(b);
                        fdis.close();
                        dos.flush();
                        break;
                    }
                }

            } else if (a.equals("DelFile")) {//�R��Server���ɮ�
                dos.writeUTF("DelFile");
                dos.writeUTF(fileName);
            }

        } catch (Exception e) {
            System.out.println("Please chooose a correct command!");
        }
        System.out.println("****************");

        // === (2) ���ݱ���Server���^��
        DataInputStream dis = new DataInputStream(querySocket.getInputStream());
        String res = dis.readUTF(); // Ū���^���r��
        System.out.println("response=" + res);
        if (res.equalsIgnoreCase("Success")) {
            if (dis.readInt() != 0) {
                int len = dis.readInt(); // �ɮת���
                byte[] b = new byte[len];
                dis.readFully(b);

                // ==== �g�J���a�ݪ��ɮרt�� ====
                FileOutputStream fos = new FileOutputStream("D:/local/" + fileName);
                fos.write(b);
                fos.close();
                System.out.println("download complete! (" + fileName + ")");
            }

        } else if (res.equalsIgnoreCase("Fail")) {
            System.out.println("file doesn't exist or delete fail!");
        }

        // === (3) ����Socket
        dos.close();
        dis.close();
        querySocket.close();
    }
}
//(a) �����ɮצ��A����"GetFile", "PutFile"���O�Aserver/client���ɮפ��O�m��c:/pub�Pc:/local��
//
//     (b) ����"DelFile"�R�O�A�i�R�����A����/pub/�ؿ������ɮ�  
//
//                       <client>                                                 <server>
//
//            (3)�R�O: DelFile, �Ѽ�: filename            (3-a) �^��: "Success", �L���[��� (�ɮצs�b�A�æ��\�R��)
//
//                                                                       (3-b) �^�� : "Fail", �L���[���   (�ɮפ��s�b�A�ΧR������)
