
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class HWK10_409630018_02 extends javax.swing.JFrame {

    File f = new File("D:/local/menu.txt");
    ArrayList<menu> menus = new ArrayList<>();
    int total = 0;

    DefaultListModel menuModel = new DefaultListModel();
    DefaultListModel orderModel = new DefaultListModel();

    class menu {

        String name;
        int price;

        public menu(String n, String p) {
            this.name = n;
            this.price = Integer.parseInt(p);
        }
    }

    public HWK10_409630018_02() throws Exception {
        initComponents();

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String s;
            while ((s = br.readLine()) != null) {
                String[] ss = s.split(" ");
                menus.add(new menu(ss[0], ss[1]));
                menuModel.addElement(ss[0]);
            }

//            String[] menuList = new String[menus.size()];
//            int cnt = 0;
//            for (menu m : menus) {
//                menuList[cnt] = m.name;
//                cnt++;
//            }
//            
//            for(String i : menuList){
//                menuModel.addElement(i);
//            }
        }

        this.MenuList.setModel(menuModel);
        this.OrderList.setModel(orderModel);
        TF2.setText(total + "");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        MenuList = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        OrderList = new javax.swing.JList<>();
        TF1 = new javax.swing.JTextField();
        TF2 = new javax.swing.JTextField();
        Add = new javax.swing.JButton();
        Del = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        MenuList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(MenuList);

        OrderList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(OrderList);

        Add.setText("Add");
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });

        Del.setText("Del");
        Del.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Add)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                    .addComponent(TF1))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Del, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TF2, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                    .addComponent(jScrollPane2))
                .addContainerGap(227, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(90, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TF1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TF2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Del, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Add, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(110, 110, 110))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        // TODO add your handling code here:
        var model = this.MenuList.getModel();
        try {
            int price = 0;

            for (menu i : menus) {
                if (model.getElementAt(this.MenuList.getSelectedIndex()).equals(i.name)) {
                    price = i.price;
                }
            }
            if (TF1.getText() == null || TF1.getText().isEmpty()) {
                orderModel.addElement(model.getElementAt(this.MenuList.getSelectedIndex()) + "->" + price);
                total += price;

            } else {
                orderModel.addElement(this.MenuList.getSelectedValue() + "->" + (price * Integer.parseInt(TF1.getText())));
                total += price * Integer.parseInt(TF1.getText());

            }

            this.OrderList.setModel(orderModel);
            TF2.setText(total + "");

        } catch (Exception e) {
            System.out.println(e);
        }

    }//GEN-LAST:event_AddActionPerformed

    private void DelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DelActionPerformed
        // TODO add your handling code here:
        var model = this.OrderList.getModel();
        try {
            String[] ss = this.OrderList.getSelectedValue().split("->");
            int price = Integer.parseInt(ss[1]);
            total -= price;
            orderModel.removeElementAt(this.OrderList.getSelectedIndex());

            TF2.setText(total + "");

        } catch (Exception e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_DelActionPerformed

    public static void main(String args[]) throws Exception {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new HWK10_409630018_02().setVisible(true);
                } catch (Exception ex) {
                    Logger.getLogger(HWK10_409630018_02.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JButton Del;
    private javax.swing.JList<String> MenuList;
    private javax.swing.JList<String> OrderList;
    private javax.swing.JTextField TF1;
    private javax.swing.JTextField TF2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
