
import java.util.Arrays;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;

public class HWK10_409630018_01 extends javax.swing.JFrame {

    String[] menus = {"�i��", "����", "�t�N", "����", "�������"};
    DefaultComboBoxModel menuModel = new DefaultComboBoxModel(menus);
    DefaultListModel orderModel = new DefaultListModel();

    public HWK10_409630018_01() {
        initComponents();

        this.Menu.setModel(menuModel);
        this.Order.setModel(orderModel);

        this.setSize(300, 300);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Select = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Menu = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        Order = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Select.setText("Select");
        Select.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectActionPerformed(evt);
            }
        });
        getContentPane().add(Select, java.awt.BorderLayout.PAGE_END);

        jPanel1.setLayout(new java.awt.GridLayout(1, 2));

        Menu.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        Menu.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                MenuValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(Menu);

        jPanel1.add(jScrollPane1);

        Order.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(Order);

        jPanel1.add(jScrollPane2);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SelectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectActionPerformed
        // TODO add your handling code here:
        int[] seldx = this.Menu.getSelectedIndices();
        var model = this.Menu.getModel();
        System.out.println(Arrays.toString(seldx));

        String[] orders = new String[seldx.length];
        for (int i = 0; i < seldx.length; i++) {
            orders[i] = model.getElementAt(seldx[i]);
        }
        for (String s : orders) {
            orderModel.addElement(s);
        }

        this.Order.setModel(orderModel);
    }//GEN-LAST:event_SelectActionPerformed

    private void MenuValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_MenuValueChanged
        // TODO add your handling code here:
        if (!evt.getValueIsAdjusting()) {
            var model = this.Menu.getModel();
            orderModel.addElement(model.getElementAt(this.Menu.getSelectedIndex()));
            
            this.Order.setModel(orderModel);
        }
    }//GEN-LAST:event_MenuValueChanged

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HWK10_409630018_01().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList<String> Menu;
    private javax.swing.JList<String> Order;
    private javax.swing.JButton Select;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
