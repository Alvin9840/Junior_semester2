
import javax.swing.*;

public class HWK10_409630018_03 extends javax.swing.JFrame {

    String[] menu = {"�i��", "����", "�t�N", "����", "�������"};
    DefaultComboBoxModel menuModel = new DefaultComboBoxModel(menu);
    DefaultListModel orderModel = new DefaultListModel();

    public HWK10_409630018_03() {
        initComponents();

        this.MenuList.setModel(menuModel);
        this.OrderList.setModel(orderModel);

        this.setSize(300, 300);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MenuList = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        Add = new javax.swing.JButton();
        Del = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        OrderList = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        MenuList.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        getContentPane().add(MenuList, java.awt.BorderLayout.PAGE_START);

        jPanel1.setLayout(new java.awt.GridLayout());

        Add.setText("Add");
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });
        jPanel1.add(Add);

        Del.setText("Del");
        Del.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DelActionPerformed(evt);
            }
        });
        jPanel1.add(Del);

        getContentPane().add(jPanel1, java.awt.BorderLayout.PAGE_END);

        OrderList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(OrderList);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        // TODO add your handling code here:
        var model = this.MenuList.getModel();

        try {
            orderModel.addElement(this.MenuList.getSelectedItem());
            this.OrderList.setModel(orderModel);

        } catch (Exception e) {
            System.out.println(e);

        }

    }//GEN-LAST:event_AddActionPerformed

    private void DelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DelActionPerformed
        // TODO add your handling code here:
        var model = this.OrderList.getModel();
        try {
            orderModel.removeElementAt(this.OrderList.getSelectedIndex());

        } catch (Exception e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_DelActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HWK10_409630018_03().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JButton Del;
    private javax.swing.JComboBox<String> MenuList;
    private javax.swing.JList<String> OrderList;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
