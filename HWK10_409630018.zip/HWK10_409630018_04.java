
import java.io.*;
import java.util.*;
import javax.swing.*;

public class HWK10_409630018_04 extends javax.swing.JFrame {

    Vector<String> colNames = new Vector<>();
    Vector<Vector> data = new Vector<>();

    public HWK10_409630018_04() {
        initComponents();

        TestSimpleTable("d:/local/test.csv");
    }

    public void TestSimpleTable(String fileName) {

        readCSVToTable(fileName, data, colNames);
        Table = new JTable(data, colNames);

        getContentPane().add(new JScrollPane(Table));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setVisible(true);
    }

    private void readCSVToTable(String fileName, Vector<Vector> data, Vector<String> colNames) {
        
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            boolean isFirstLine = true;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (isFirstLine) {
                    colNames.addAll(Arrays.asList(values));
                    System.out.print(Arrays.toString(values));
                    isFirstLine = false;
                    
                } else {
                    Vector<Object> row = new Vector<>();
                    for (String value : values) {
                        row.add(value);
                    }
                    data.add(row);
                    
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
            
        }
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Table = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(Table);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HWK10_409630018_04().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Table;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
