
import java.net.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HWK6_409630018_02_Server extends javax.swing.JFrame {

    public HWK6_409630018_02_Server() throws IOException {
        initComponents();
    }

    calThread t = new calThread();

    class calThread extends Thread {

        boolean run = true;

        public void run() {
            while (run) {
                try {
                    run_server();
                } catch (Exception e) {
                    System.out.println("e = " + e);
                }
            }
        }

        public void run_server() throws Exception {
            ServerSocket ss = new ServerSocket(4444);
            while (run) {
                Socket client = ss.accept();
                String s = new DataInputStream(client.getInputStream()).readUTF();

                String[] sp = s.split(",");
                Server.append("accept a request:" + sp[0] + sp[1] + sp[2] + "\n");
                DataOutputStream dop = new DataOutputStream(client.getOutputStream());
                double ans = 0;
                double n1 = Double.parseDouble(sp[0]);
                double n2 = Double.parseDouble(sp[2]);

                if (sp[1].equals("+")) {
                    ans = n1 + n2;
                } else if (sp[1].equals("-")) {
                    ans = n1 - n2;
                } else if (sp[1].equals("*")) {
                    ans = n1 * n2;
                } else if (sp[1].equals("/")) {
                    ans = n1 / n2;
                }

                Server.append("reply:" + ans + "\n");
                dop.writeUTF(ans + "");
                ss.close();

            }
        }

        void setRun(boolean b) {
            run = b;
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Start = new javax.swing.JButton();
        Stop = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Server = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Start.setText("Start");
        Start.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StartActionPerformed(evt);
            }
        });

        Stop.setText("Stop");
        Stop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StopActionPerformed(evt);
            }
        });

        jLabel1.setText("Socket Server");

        Server.setColumns(20);
        Server.setRows(5);
        jScrollPane1.setViewportView(Server);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addComponent(Start)
                        .addGap(18, 18, 18)
                        .addComponent(Stop))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addComponent(jLabel1)))
                .addContainerGap(95, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Start)
                    .addComponent(Stop))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(56, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void StartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StartActionPerformed
        Server.append("Server Init...");

        if (!t.isAlive()) {
            t.start();
        } else {
            t.setRun(true);
        }

    }//GEN-LAST:event_StartActionPerformed


    private void StopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StopActionPerformed
        // TODO add your handling code here:
        if (t.isAlive()) {
            t.setRun(false);
            t = new calThread();
        }
    }//GEN-LAST:event_StopActionPerformed

    public static void main(String args[]) throws IOException {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new HWK6_409630018_02_Server().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(HWK6_409630018_02_Server.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea Server;
    private javax.swing.JButton Start;
    private javax.swing.JButton Stop;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
