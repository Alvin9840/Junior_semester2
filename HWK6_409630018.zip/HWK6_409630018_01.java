
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import javax.net.ssl.HttpsURLConnection;

public class HWK6_409630018_01 extends javax.swing.JFrame {

    public HWK6_409630018_01() {
        initComponents();
        setSize(600, 600);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        queryTf = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        mainPane = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setPreferredSize(new java.awt.Dimension(400, 35));
        jPanel1.setLayout(new java.awt.BorderLayout());
        jPanel1.add(queryTf, java.awt.BorderLayout.CENTER);

        jButton1.setText("Google");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, java.awt.BorderLayout.LINE_END);

        getContentPane().add(jPanel1, java.awt.BorderLayout.PAGE_START);

        mainPane.setColumns(20);
        mainPane.setLineWrap(true);
        mainPane.setRows(5);
        jScrollPane1.setViewportView(mainPane);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        doSearch();
    }//GEN-LAST:event_jButton1ActionPerformed
    private void doSearch() {
        try {
            // === �ǳƬd�ߦr��(query string), ����URL����
            String part1 = "https://www.google.com.tw/search?hl=zh-TW&q=";
            String qString = URLEncoder.encode(queryTf.getText(), "Big5");
            String part2 = "&meta=&aq=f&gws_rd=ssl";
            URL url = new URL(part1 + qString + part2);
            System.out.println(url.toExternalForm());

            // === ���˥��s�u�O�s�����A�H�KHTTP Server���d, �t�i��HttpsURLConnection
            HttpsURLConnection uc = (HttpsURLConnection) url.openConnection();
            uc.addRequestProperty("User-Agent", " Firefox/3.0.10");

            InputStreamReader isr = new InputStreamReader(uc.getInputStream(), "Big5"); // or utf-8
            BufferedReader br = new BufferedReader(isr);
            String inputLine = "", allStr = "";
            while ((inputLine = br.readLine()) != null) {

                //�L�X�����W��
                if (inputLine.contains("<span class=\"fYyStc\">")) {
                    int n1 = inputLine.indexOf("<span class=\"fYyStc\">");
                    if (n1 != -1) {
                        String s1 = inputLine.substring(n1 + "<span class=\"fYyStc\">".length());
                        int n2 = s1.indexOf("</span>");
                        String s2 = s1.substring(0, n2);
                        System.out.println("#" + s2);
                    }
                }

                //�L�X���}
                if (inputLine.contains("<a href=\"/url?q=")) {
                    int n1 = inputLine.indexOf("<a href=\"/url?q=");
                    if (n1 != -1) {
                        String s1 = inputLine.substring(n1 + "<a href=\"/url?q=".length());
                        int n2 = s1.indexOf("&");
                        String s2 = s1.substring(0, n2);
                        System.out.println(s2);

                    }
                }

                allStr += (inputLine + "\n");
            }
            br.close();
            mainPane.setText(allStr);
        } catch (Exception e) {
            System.out.println("e = " + e);
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HWK6_409630018_01().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea mainPane;
    private javax.swing.JTextField queryTf;
    // End of variables declaration//GEN-END:variables
}
