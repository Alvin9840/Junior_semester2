
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class HWK1_409630018_03_JFrame1 extends javax.swing.JFrame {

    int point = 100;
    int pp, ip, cp, temp;

    public HWK1_409630018_03_JFrame1() {
        initComponents();
        temp = point;
        pp = 0;
        ip = 0;
        cp = 0;
        this.Total.setText(String.valueOf(temp));
        this.Phisical_Text.setText(String.valueOf(pp));
        this.Intelligence_Text.setText(String.valueOf(ip));
        this.Charm_Text.setText(String.valueOf(cp));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Phisical = new javax.swing.JSlider();
        Intelligence = new javax.swing.JSlider();
        Charm = new javax.swing.JSlider();
        jLabel1 = new javax.swing.JLabel();
        JLable2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Phisical_Text = new javax.swing.JTextField();
        Intelligence_Text = new javax.swing.JTextField();
        Charm_Text = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        Total = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Phisical.setMajorTickSpacing(10);
        Phisical.setMinorTickSpacing(5);
        Phisical.setPaintLabels(true);
        Phisical.setPaintTicks(true);
        Phisical.setToolTipText("");
        Phisical.setValue(0);
        Phisical.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                PhisicalStateChanged(evt);
            }
        });

        Intelligence.setMajorTickSpacing(10);
        Intelligence.setMinorTickSpacing(5);
        Intelligence.setPaintLabels(true);
        Intelligence.setPaintTicks(true);
        Intelligence.setValue(0);
        Intelligence.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                IntelligenceStateChanged(evt);
            }
        });

        Charm.setMajorTickSpacing(10);
        Charm.setMinorTickSpacing(5);
        Charm.setPaintLabels(true);
        Charm.setPaintTicks(true);
        Charm.setValue(0);
        Charm.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                CharmStateChanged(evt);
            }
        });

        jLabel1.setText("體力");

        JLable2.setText("智力");

        jLabel3.setText("魅力");

        Phisical_Text.setMinimumSize(new java.awt.Dimension(70, 22));
        Phisical_Text.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Phisical_TextActionPerformed(evt);
            }
        });

        Intelligence_Text.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Intelligence_TextActionPerformed(evt);
            }
        });

        jLabel4.setText("總點數:");

        Total.setText("200");
        Total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(127, 127, 127)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(JLable2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Phisical, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Phisical_Text, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Intelligence, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Charm, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Intelligence_Text, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Charm_Text, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(109, 109, 109)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(161, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Phisical, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Phisical_Text, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Intelligence_Text, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JLable2, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Intelligence, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(Charm_Text, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(Charm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addContainerGap(95, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void Phisical_TextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Phisical_TextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Phisical_TextActionPerformed

    private void TotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TotalActionPerformed

    private void Intelligence_TextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Intelligence_TextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Intelligence_TextActionPerformed

    private void PhisicalStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_PhisicalStateChanged
        // TODO add your handling code here:
        temp = Integer.parseInt(this.Total.getText());
        pp = Integer.parseInt(this.Phisical_Text.getText());
        ip = Integer.parseInt(this.Intelligence_Text.getText());
        cp = Integer.parseInt(this.Charm_Text.getText());
        if ((point - pp) >= (ip + cp)) {
            this.Phisical_Text.setText(String.valueOf(pp));
            this.Total.setText(String.valueOf(temp));
        }
        if (temp < 0) {
            this.Phisical_Text.setText(String.valueOf(temp));
            this.Phisical.setValue(temp);
        }
    }//GEN-LAST:event_PhisicalStateChanged

    private void IntelligenceStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_IntelligenceStateChanged
        // TODO add your handling code here:
        temp = Integer.parseInt(this.Total.getText());
        pp = Integer.parseInt(this.Phisical_Text.getText());
        ip = Integer.parseInt(this.Intelligence_Text.getText());
        cp = Integer.parseInt(this.Charm_Text.getText());
        if ((point - ip) >= (pp + cp)) {
            this.Intelligence_Text.setText(ip + "");
            this.Total.setText(temp + "");
        }
        if (temp < 0) {
            this.Intelligence_Text.setText(temp + "");
            this.Phisical.setValue(temp);
        }
    }//GEN-LAST:event_IntelligenceStateChanged

    private void CharmStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_CharmStateChanged
        // TODO add your handling code here:
        temp = Integer.parseInt(this.Total.getText());
        pp = Integer.parseInt(this.Phisical_Text.getText());
        ip = Integer.parseInt(this.Intelligence_Text.getText());
        cp = Integer.parseInt(this.Charm_Text.getText());
        if ((point - cp) >= (ip + pp)) {
            this.Charm_Text.setText(cp + "");
            this.Total.setText(temp + "");
        }
        if (temp < 0) {
            this.Charm_Text.setText(temp + "");
            this.Phisical.setValue(temp);
        }
    }//GEN-LAST:event_CharmStateChanged

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HWK1_409630018_03_JFrame1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSlider Charm;
    private javax.swing.JTextField Charm_Text;
    private javax.swing.JSlider Intelligence;
    private javax.swing.JTextField Intelligence_Text;
    private javax.swing.JLabel JLable2;
    private javax.swing.JSlider Phisical;
    private javax.swing.JTextField Phisical_Text;
    private javax.swing.JTextField Total;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    // End of variables declaration//GEN-END:variables
}
