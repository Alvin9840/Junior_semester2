
public class HWK1_409630018_01_JFrame1 extends javax.swing.JFrame {

    public HWK1_409630018_01_JFrame1() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Meal_A = new javax.swing.JRadioButton();
        Meal_B = new javax.swing.JRadioButton();
        Meal_C = new javax.swing.JRadioButton();
        Enlarge_Fries = new javax.swing.JCheckBox();
        Enlarge_Drink = new javax.swing.JCheckBox();
        Total = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("總金額: ");
        jLabel1.setToolTipText("");

        jLabel2.setText("(主餐一律99元)");

        buttonGroup1.add(Meal_A);
        Meal_A.setText("A附餐(50元)");
        Meal_A.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Meal_AActionPerformed(evt);
            }
        });

        buttonGroup1.add(Meal_B);
        Meal_B.setText("B附餐(70元)");
        Meal_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Meal_BActionPerformed(evt);
            }
        });

        buttonGroup1.add(Meal_C);
        Meal_C.setText("C附餐(70元)");
        Meal_C.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Meal_CActionPerformed(evt);
            }
        });

        Enlarge_Fries.setText("飲料加大(+5元)");
        Enlarge_Fries.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Enlarge_FriesActionPerformed(evt);
            }
        });

        Enlarge_Drink.setText("薯條加大(+5元)");
        Enlarge_Drink.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Enlarge_DrinkActionPerformed(evt);
            }
        });

        Total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Meal_C)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Meal_A)
                                    .addComponent(Meal_B))
                                .addGap(48, 48, 48)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Enlarge_Drink)
                                    .addComponent(Enlarge_Fries))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(129, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Meal_A)
                    .addComponent(Enlarge_Fries))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Meal_B)
                    .addComponent(Enlarge_Drink))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Meal_C)
                .addContainerGap(170, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    int t = 99;
    private void TotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_TotalActionPerformed

    private void Meal_AActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Meal_AActionPerformed
        // TODO add your handling code here:if (Meal_A.isSelected()) {
        Enlarge_Drink.setSelected(false);
        Enlarge_Fries.setSelected(false);
        t = 99;
        t += 50;
        Total.setText(t + "");
    }//GEN-LAST:event_Meal_AActionPerformed

    private void Meal_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Meal_BActionPerformed
        // TODO add your handling code here:f (Meal_B.isSelected()) {
        Enlarge_Drink.setSelected(false);
        Enlarge_Fries.setSelected(false);
        t = 99;
        t += 70;
        Total.setText(t + "");
    }//GEN-LAST:event_Meal_BActionPerformed

    private void Meal_CActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Meal_CActionPerformed
        // TODO add your handling code here:if (Meal_C.isSelected()) {
        Enlarge_Drink.setSelected(false);
        Enlarge_Fries.setSelected(false);
        t = 99;
        t += 90;
        Total.setText(t + "");
    }//GEN-LAST:event_Meal_CActionPerformed

    private void Enlarge_FriesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Enlarge_FriesActionPerformed
        // TODO add your handling code here:if (Enlarge_Fries.isSelected()) {
        if (Enlarge_Fries.isSelected()) {
            t += 5;
            Total.setText(t + "");
        } else {
            t -= 5;
            Total.setText(t + "");
        }
    }//GEN-LAST:event_Enlarge_FriesActionPerformed

    private void Enlarge_DrinkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Enlarge_DrinkActionPerformed
        // TODO add your handling code here:if (Enlarge_Drink.isSelected()) {
        if (Enlarge_Drink.isSelected()) {
            t += 5;
            Total.setText(t + "");
        } else {
            t -= 5;
            Total.setText(t + "");
        }
    }//GEN-LAST:event_Enlarge_DrinkActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HWK1_409630018_01_JFrame1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox Enlarge_Drink;
    private javax.swing.JCheckBox Enlarge_Fries;
    private javax.swing.JRadioButton Meal_A;
    private javax.swing.JRadioButton Meal_B;
    private javax.swing.JRadioButton Meal_C;
    private javax.swing.JTextField Total;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
