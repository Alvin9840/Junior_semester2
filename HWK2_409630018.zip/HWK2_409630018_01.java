
import java.util.*;

class OprThread extends Thread {

    int[] a, b, c;
    char opr;

    OprThread(int[] a, int[] b, int[] c, char opr) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.opr = opr;
    }

    @Override
    public void run() {
        for (int i = 0; i < c.length; i++) {
            if (opr == '+') {
                c[i] = a[i] + b[i];
            } else if (opr == '-') {
                c[i] = a[i] - b[i];
            } else if (opr == '*') {
                c[i] = a[i] * b[i];
            } else if (opr == '/') {
                c[i] = a[i] / b[i];
            }
        }
    }
}

public class HWK2_409630018_01 {

    public static void main(String[] args) throws Exception {
        int[] a = new int[100], b = new int[100];
        int[] c = new int[100], d = new int[100];
        int[] e = new int[100], f = new int[100];
        // … 亂數填入a[], b[]的值, 範圍[50,200]
        Random r = new Random(111);
        for (int i = 0; i < a.length; i++) {
            a[i] = 50 + r.nextInt(200 - 50 + 1);
            b[i] = 50 + r.nextInt(200 - 50 + 1);
        }

        // operation(a, b, c, '+'); // -> Thread 1
        // operation(a, b, d, '-'); // -> Thread 2
        Thread t1 = new OprThread(a, b, c, '+');
        Thread t2 = new OprThread(a, b, d, '-');
        Thread t3 = new OprThread(a, b, e, '*');
        Thread t4 = new OprThread(a, b, f, '/');

        t1.start();
        t2.start();
        t3.start();
        t4.start();

        t1.join();
        t2.join();
        t3.join();
        t4.join();
        System.out.println("c[]=" + Arrays.toString(c));
        System.out.println("d[]=" + Arrays.toString(d));
        System.out.println("e[]=" + Arrays.toString(e));
        System.out.println("f[]=" + Arrays.toString(f));
    }
}
