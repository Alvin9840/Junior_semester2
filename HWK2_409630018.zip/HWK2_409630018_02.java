
import java.time.Duration;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

class PrintThread extends Thread {

    String s;
    int times;
    double duration;

    PrintThread() {

    }

    PrintThread(String s, int times, double duration) {
        this.s = s;
        this.times = times;
        this.duration = duration;
    }

    @Override
    public void run() {
        for (int i = 0; i < times; i++) {
            try {
                System.out.println(s);
                Thread.sleep((long) duration * 1000);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

public class HWK2_409630018_02 {

    public static void main(String[] args) {
        new PrintThread("Hello", 15, 0.5).start(); //印出"Hello", 共15次，每隔0.5秒印出一次
        new PrintThread("hi", 10, 1.5).start();
        new PrintThread("<Root>", 12, 1).start();
    }
}
