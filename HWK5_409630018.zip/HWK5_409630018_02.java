
import java.net.*;
import java.io.*;
import java.util.Arrays;

public class HWK5_409630018_02 {

    public static void main(String[] args) throws Exception {
        URL[] urls = new URL[5];
        urls[0] = new URL("https://www.thewowstyle.com/wp-content/uploads/2015/01/nature-images..jpg");
        urls[1] = new URL("https://logos-download.com/wp-content/uploads/2016/06/Playstation_logo_black.png");
        urls[2] = new URL("https://logos-download.com/wp-content/uploads/2016/02/BMW_logo_big_transparent_png.png");
        urls[3] = new URL("https://www.carlogos.org/car-logos/tesla-logo-2200x2800.png");
        urls[4] = new URL("https://www.thewowstyle.com/wp-content/uploads/2015/01/nature-images.jpg");

        for (int i = 0; i < urls.length; i++) {
            Save_url(urls[i], "D:/Data/Image" + (i + 1) + ".jpg");
        }

        //�U��
        String[] arr = new String[5];
        BufferedReader bf = new BufferedReader(new FileReader("C:\\Data\\pictures\\picURL.txt"));
        for (int i = 0; i < arr.length; i++) {
            arr[i] = bf.readLine();
        }
        System.out.println(Arrays.toString(arr));
        for (int i = 0; i < arr.length; i++) {
            URL url = new URL(arr[i]);
            URLConnection uc = url.openConnection();
            InputStream is = uc.getInputStream();
            int len = uc.getContentLength();  //  �^����URL������(byte��)
            byte[] bs = new byte[len]; // �w�Ƥ@�}�C�x�s���i�Ϥ�
            DataInputStream dis = new DataInputStream(is); //�]��Wrap
            dis.readFully(bs);// �z�Ldis��y�A�Nbs[]�˺�
            dis.close();
            // --- �g�J���a�� ---
            String[] file = arr[i].split("/");
            //System.out.println("Filename:"+file[file.length-1]);
            String filename = file[file.length - 1];
            FileOutputStream fos = new FileOutputStream("C:/Data/pictures/pic" + filename);
            fos.write(bs);
            fos.close();
        }
    }

    public static void Save_url(URL u, String path) throws Exception {
        URLConnection uc = u.openConnection();
        int len = uc.getContentLength();
        byte[] bs = new byte[len];

        InputStream is = uc.getInputStream();
        DataInputStream dis = new DataInputStream(is);
        dis.readFully(bs);

        dis.close();
        is.close();

        FileOutputStream fos = new FileOutputStream(path);
        fos.write(bs);
        fos.close();
    }
}
