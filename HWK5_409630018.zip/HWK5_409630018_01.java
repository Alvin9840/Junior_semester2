
import java.net.*;
import java.io.*;
import java.util.*;

class ConnectionRunnable implements Runnable {

    URL url;

    ConnectionRunnable(URL u) {
        this.url = u;
    }

    @Override
    public void run() {

        while (true) {
            try {
                if (IsContain(url)) {
                    System.out.println(url + " (V)");
                } else {
                    System.out.println(url + " (X)");
                }
                Thread.sleep(600 * 1000);

            } catch (Exception e) {
                System.out.println("e:" + e);
            }
        }
    }

    public boolean IsContain(URL url) throws Exception {

        URLConnection uc = url.openConnection();
        InputStream is = uc.getInputStream();

        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String s;
        while ((s = br.readLine()) != null) {
            if (s.contains("���")) {
                return true;
            }
        }

        return false;
    }
}

public class HWK5_409630018_01 {

    public static void main(String[] args) throws Exception {

        System.out.println("�}�l�j�M...");

        URL url_yahoo = new URL("https://tw.yahoo.com/");
        new Thread(new ConnectionRunnable(url_yahoo)).start();

        URL url_hinet = new URL("https://www.hinet.net/");
        new Thread(new ConnectionRunnable(url_hinet)).start();

        URL url_pchome = new URL(" https://www.pchome.com.tw/");
        new Thread(new ConnectionRunnable(url_pchome)).start();
    }

}
